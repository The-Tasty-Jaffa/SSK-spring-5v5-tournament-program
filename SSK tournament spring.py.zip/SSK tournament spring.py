import random #Imports a random function

team = ' '
teams = list()
teams_edit = list()

while team != '':
    team = input("Enter name of team:\n>>> ")
    if team != '':
        teams.append(team)

print("Here are all the teams which have been entered:")
for x in teams:
    print(">>>", x)

if input("Do you want to makethe groups? -(y/n)- ") == 'y':
    random.shuffle(teams)
    teams_edit = teams
    teams_processed = []
    while len(teams_edit) != 0:
        for x in range(0,4):
            while True:
                try:
                    teams_processed.append(teams_edit.pop())
                    break
                except:
                    break
        print("Here is one group", teams_processed)
        teams_processed = []


